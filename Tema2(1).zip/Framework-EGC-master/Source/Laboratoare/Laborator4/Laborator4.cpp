#include "Laborator4.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>
#include "Transform3D.h"

using namespace std;

Laborator4::Laborator4()
{
}

Laborator4::~Laborator4()
{
}

void Laborator4::Init()
{
	polygonMode = GL_FILL;
	glm::ivec2 resolution = window->GetResolution();

	Mesh* mesh = new Mesh("box");
	mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
	meshes[mesh->GetMeshID()] = mesh;

	//rotatie nori
	viteza = 0;

	// initialize tx, ty and tz (the translation steps)
	translateX = 0;
	translateY = 0;
	translateZ = 0;

	// initialize sx, sy and sz (the scale factors)
	scaleX = 1;
	scaleY = 1;
	scaleZ = 1;

	// initialize angularSteps
	angularStepOX = 0;
	angularStepOY = 0;
	angularStepOZ = 0;

	//indice de deplasare
	tx = resolution.x;

}

void Laborator4::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Laborator4::Update(float deltaTimeSeconds)
{
	glLineWidth(3);
	glPointSize(5);
	glPolygonMode(GL_FRONT_AND_BACK, polygonMode);
	glm::ivec2 resolution = window->GetResolution();

	angularStepOZ -= deltaTimeSeconds / 4;

	//desenam avionul si facem si miscarea pentru el in functie de translateY
	//adaugam si inclinatie pentru pasare (??)

	//coada avionului
	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(-0.4f, translateY, -1.5f);
	modelMatrix *= Transform3D::Scale(-0.2, -0.3, -0.3);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	//corpul avionului
	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(-0.1f, translateY, -1.5f);
	modelMatrix *= Transform3D::Scale(0.6, 0.6, 0.6);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	//suport elice
	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(0.3f, translateY, -1.5f);
	modelMatrix *= Transform3D::Scale(-0.2, -0.1, -0.1);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	//elice
	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(0.4f, translateY, -1.5f);
	modelMatrix *= Transform3D::Scale(-0.1, -0.6, -0.6);
	angularStepOX += 10 * deltaTimeSeconds;
	modelMatrix *= Transform3D::RotateOX(angularStepOX);//elicea are o miscare de rotatie mereu
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	//aripa dreapta 
	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(-0.05f, translateY + 0.2f, -0.4f);
	modelMatrix *= Transform3D::Scale(-0.3, -0.2, -0.2);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	//aripa stanga 
	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(-0.05f, translateY + 0.2f, -1.7f);
	modelMatrix *= Transform3D::Scale(-0.3, -0.2, -0.2);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	///////////////////////////////////////////////////////////////////////////////////////
	//desenarea Norilor
	//generam la pozitii aleatoare nori
	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(1.05f, 1.0f, 1.0f);
	modelMatrix *= Transform3D::Scale(-0.09, -0.09, -0.09);
	modelMatrix *= Transform3D::RotateOZ(0.5);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(1.0f, 1.1f, 1.2f);
	modelMatrix *= Transform3D::Scale(0.07, 0.07, 0.07);
	//rotatie continua
	viteza += 1.5 * deltaTimeSeconds;
	modelMatrix *= Transform3D::RotateOX(viteza);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(1.0f, 1.0f, 1.2f);
	modelMatrix *= Transform3D::Scale(0.05, 0.05, 0.05);
	modelMatrix *= Transform3D::RotateOZ(-0.5);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(1.05f, 1.0f, 1.2f);
	modelMatrix *= Transform3D::Scale(0.07, 0.07, 0.07);
	modelMatrix *= Transform3D::RotateOZ(0.3);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

}

void Laborator4::FrameEnd()
{
	DrawCoordinatSystem();
}

void Laborator4::OnInputUpdate(float deltaTime, int mods)
{
	// TODO
}

void Laborator4::OnKeyPress(int key, int mods)
{
	// add key press event

}

void Laborator4::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator4::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	//deplasarea sus-jos a avionului depinde de mouse
	float speed = 0.004f;
	translateY += -speed * deltaY;
	angularStepOZ = 0.5;
}

void Laborator4::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Laborator4::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator4::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator4::OnWindowResize(int width, int height)
{
}
